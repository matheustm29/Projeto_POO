//Matheus Ferreira Alphonse dos Anjos 2454220

public class Info{

	private int cod = 0;
	private String marca= "";


	public int getCod(){
		return cod;
	}

	public String getMarca(){
		return marca;
	}

	public void setCod(int cod){
		this.cod = cod;
	}

	public void setMarca(String marca){
		this.marca = marca;
	}
	

}