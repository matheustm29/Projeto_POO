//Matheus Ferreira Alphonse dos Anjos 2454220

public interface DescontoJoia{

	public double calcularDesconto(); 

}

